import openai
from transformers import pipeline
import matplotlib.pyplot as plt
import streamlit as st
import pickle

# Set OpenAI API key
openai.api_key = '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'

# Initialize Hugging Face sentiment analysis pipeline
sentiment_analysis = pipeline('sentiment-analysis', model="distilbert/distilbert-base-uncased-finetuned-sst-2-english")

# Filename for the pickle file
PICKLE_FILE = 'sentiments_data.pkl'

# GPT-3 Response Generation
def generate_gpt3_response(user_input):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # Use GPT-3.5 Turbo engine
        messages=[
            {"role": "system", "content": "You are an AI assistant."},
            {"role": "user", "content": user_input}
        ],
        max_tokens=100
    )
    return response['choices'][0]['message']['content'].strip()

# Sentiment Analysis using Hugging Face
def analyze_sentiment(text):
    analysis = sentiment_analysis(text)[0]
    return analysis['label']

# Save sentiments to a pickle file
def save_sentiments_to_pickle(data, filename=PICKLE_FILE):
    with open(filename, 'wb') as file:
        pickle.dump(data, file)

#  Load sentiments from a pickle file
def load_sentiments_from_pickle(filename=PICKLE_FILE):
    try:
        with open(filename, 'rb') as file:
            data = pickle.load(file)
    except FileNotFoundError:
        data = []  # If the file doesn't exist, return an empty list
    return data

# Visualization Function
def visualize_sentiment(sentiments):
    sentiment_count = {
        'POSITIVE': sentiments.count('POSITIVE'),
        'NEUTRAL': sentiments.count('NEUTRAL'),
        'NEGATIVE': sentiments.count('NEGATIVE')
    }
    labels = sentiment_count.keys()
    sizes = sentiment_count.values()

    # Create pie chart
    fig, ax = plt.subplots(figsize=(7, 7))
    ax.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
    ax.axis('equal')
    plt.title('Sentiment Distribution')
    st.pyplot(fig)

# Streamlit App
def main():
    st.title("AI Chat with Sentiment Analysis")

    # Load previously saved sentiments from pickle file
    sentiments = load_sentiments_from_pickle()

    user_input = st.text_input("Enter your message:")

    if st.button('Generate Sentiment'):
        if user_input:
            # Generate GPT-3 response
            gpt3_response = generate_gpt3_response(user_input)
            st.subheader("GPT-3 Response:")
            st.write(gpt3_response)

            # Perform Sentiment Analysis
            sentiment = analyze_sentiment(gpt3_response)
            st.subheader("Sentiment:")
            st.write(f"Sentiment: {sentiment}")

            # Store sentiment results
            sentiments.append(sentiment)

            # Save sentiments to the pickle file
            save_sentiments_to_pickle(sentiments)

    # Button to visualize sentiment distribution
    if st.button('Visualize Sentiment'):
        if len(sentiments) > 0:
            st.subheader("Sentiment Analysis Distribution")
            visualize_sentiment(sentiments)
        else:
            st.write("No sentiments available for visualization.")

if __name__ == "__main__":
    main()

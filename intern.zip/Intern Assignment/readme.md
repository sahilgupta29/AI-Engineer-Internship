AI Chat with Sentiment Analysis and Visualization
This project is a Python-based interactive program that uses OpenAI's GPT-3.5 Turbo model to generate responses based on user input, performs sentiment analysis on the generated responses using Hugging Face's distilbert model, and visualizes sentiment distribution. The project also saves sentiment analysis results and allows users to visualize the sentiment data over time.

Features
GPT-3.5 Turbo Response Generation: Generates a response to user input using OpenAI's GPT-3.5 Turbo API.
Sentiment Analysis: Classifies the sentiment of GPT-3 responses as either Positive, Neutral, or Negative using Hugging Face's sentiment analysis model.
Sentiment Data Persistence: Saves analyzed sentiments in a pickle file, allowing for data persistence across multiple runs.
Data Visualization: Visualizes the distribution of sentiments using a pie chart.
Approach
User Input: The user provides a message through the Streamlit interface.
GPT-3 Response Generation: The user’s input is passed to OpenAI’s GPT-3.5 Turbo model, which generates a response. This response simulates a conversation with an AI assistant.
Sentiment Analysis: The generated response is analyzed for sentiment (Positive, Neutral, Negative) using Hugging Face's distilbert-base-uncased-finetuned-sst-2-english model.
Data Storage: The sentiment results are saved in a pickle file for future reference.
Visualization: A pie chart is generated to show the distribution of sentiment categories from previous conversations.
Installation
Prerequisites
Python 3.8 or later
OpenAI API Key
Internet connection to access OpenAI and Hugging Face APIs
Libraries
You will need the following Python libraries:

openai: For interaction with OpenAI's GPT-3.5 Turbo.
transformers: For Hugging Face sentiment analysis.
streamlit: For building the interactive web app.
pickle: To save and load sentiment data.
matplotlib and seaborn: For creating the sentiment distribution pie chart.
Install the required libraries with the following command:

bash
pip install openai transformers streamlit matplotlib seaborn
Usage
Set the OpenAI API Key: Replace 'your-openai-api-key' in the Python file with your actual OpenAI API key. To obtain the key, visit OpenAI.

Run the Streamlit App: Open a terminal or command prompt and run the following command:

bash

streamlit run path_to_your_python_file.py
Replace path_to_your_python_file.py with the path to the Python script.

Generate Responses and Sentiment:

Enter a message in the text input box.
Click the "Generate Sentiment" button to get a GPT-3 response and sentiment analysis.
Visualize Sentiments:

Click the "Visualize Sentiment" button to see a pie chart of the sentiment distribution from previously analyzed responses.
Project Structure
bash
Copy code

├── project.py                # Main Python script for the project
└── README.md                 # Project documentation
Example
After running the application:

Enter a message such as "The weather is great today."
The AI will generate a response.
The sentiment analysis might return "POSITIVE" based on the response.
If you click "Visualize Sentiment," a pie chart will appear, showing how many positive, neutral, and negative responses were recorded.
Limitations
The current implementation uses the GPT-3.5 Turbo model, which may require an OpenAI API subscription.
API rate limits may apply if you exceed the quota for the OpenAI API.
Future Enhancements
Integration of more sophisticated NLP models for sentiment analysis.
Additional functionalities such as topic modeling or emotion detection.
Extending the visualization options for better data insights.
License
This project is licensed under the MIT License.

This README provides an overview of the project, the approach taken, and instructions to get the program up and running.





